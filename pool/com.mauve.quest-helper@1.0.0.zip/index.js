// Mauve Quest Helper for Revenge (Android)
// Safe port of the original extension's helper UI. It intentionally does not
// spoof User-Agent/platform, fake running games/streams, or submit quest progress.

const QUEST_URL = 'https://discord.com/quest-home';
const STEPS = [
  'Open Quests and read the requirements for the quest you accepted.',
  'Start the game, video, or activity exactly as Discord asks.',
  'Let Discord record the activity normally; keep the required app or page open.',
  'Return to Quests, check Discord’s own progress indicator, and claim the reward if available.'
];

const COLORS = {
  base: '#1E1E2E',
  surface: '#313244',
  surfaceAlt: '#45475A',
  text: '#CDD6F4',
  muted: '#A6ADC8',
  mauve: '#CBA6F7',
  green: '#A6E3A1',
  border: '#585B70'
};

const styles = {
  page: { flexGrow: 1, backgroundColor: COLORS.base, padding: 16 },
  hero: { backgroundColor: COLORS.surface, borderColor: COLORS.border, borderWidth: 1, borderRadius: 18, padding: 18, marginBottom: 16 },
  eyebrow: { color: COLORS.mauve, fontSize: 12, fontWeight: '800', letterSpacing: 1.2, marginBottom: 8 },
  title: { color: COLORS.text, fontSize: 24, fontWeight: '800', marginBottom: 8 },
  subtitle: { color: COLORS.muted, fontSize: 14, lineHeight: 20 },
  progress: { color: COLORS.mauve, fontSize: 13, fontWeight: '700', marginTop: 14 },
  sectionTitle: { color: COLORS.text, fontSize: 16, fontWeight: '800', marginBottom: 10 },
  step: { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: COLORS.surface, borderColor: COLORS.border, borderWidth: 1, borderRadius: 14, padding: 13, marginBottom: 9 },
  stepDone: { borderColor: COLORS.mauve, backgroundColor: '#30283F' },
  checkbox: { width: 23, height: 23, borderRadius: 7, borderWidth: 1.5, borderColor: COLORS.muted, alignItems: 'center', justifyContent: 'center', marginRight: 11, marginTop: 1 },
  checkboxDone: { backgroundColor: COLORS.mauve, borderColor: COLORS.mauve },
  checkmark: { color: COLORS.base, fontSize: 15, fontWeight: '900' },
  stepText: { color: COLORS.text, fontSize: 14, lineHeight: 20, flex: 1 },
  button: { minHeight: 48, borderRadius: 13, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, paddingVertical: 12, marginTop: 5, marginBottom: 8, backgroundColor: COLORS.mauve },
  buttonSecondary: { backgroundColor: COLORS.surfaceAlt, borderWidth: 1, borderColor: COLORS.border },
  buttonText: { color: COLORS.base, fontSize: 14, fontWeight: '800' },
  secondaryText: { color: COLORS.text },
  note: { color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: 8, marginBottom: 12 },
  status: { color: COLORS.green, fontSize: 13, lineHeight: 19, marginTop: 2, marginBottom: 8 }
};

function SettingsComponent({ api }) {
  const runtime = api?.unscoped?.react;
  const React = runtime?.React;
  const RN = runtime?.ReactNative;
  if (!React || !RN) return null;

  const { View, Text, ScrollView, Pressable, Linking } = RN;
  const [checked, setChecked] = React.useState([false, false, false, false]);
  const [status, setStatus] = React.useState('Checklist progress is local to this settings screen and resets when the screen remounts.');

  const completed = checked.filter(Boolean).length;
  const toggleStep = (index) => setChecked((current) => current.map((value, i) => i === index ? !value : value));
  const openQuests = async () => {
    try {
      if (!Linking?.openURL) throw new Error('Link opening is not available in this build.');
      await Linking.openURL(QUEST_URL);
      setStatus('Opened the official Discord Quest page link. Complete the activity normally in Discord.');
    } catch (error) {
      setStatus('Could not open the link automatically. Visit discord.com/quest-home in your browser.');
    }
  };
  const resetChecklist = () => {
    setChecked([false, false, false, false]);
    setStatus('Checklist reset.');
  };

  return React.createElement(ScrollView, { contentContainerStyle: styles.page },
    React.createElement(View, { style: styles.hero },
      React.createElement(Text, { style: styles.eyebrow }, 'CATPPUCCIN MOCHA  •  MAUVE'),
      React.createElement(Text, { style: styles.title }, 'Quest Helper'),
      React.createElement(Text, { style: styles.subtitle }, 'A tiny helper for keeping track of Discord Quest steps on mobile. It leaves quest activity and progress reporting to Discord.'),
      React.createElement(Text, { style: styles.progress }, `${completed} / ${STEPS.length} steps checked`)
    ),
    React.createElement(Text, { style: styles.sectionTitle }, 'Your checklist'),
    ...STEPS.map((step, index) => React.createElement(Pressable, {
      key: `step-${index}`,
      onPress: () => toggleStep(index),
      accessibilityRole: 'checkbox',
      accessibilityState: { checked: checked[index] },
      style: [styles.step, checked[index] ? styles.stepDone : null]
    },
      React.createElement(View, { style: [styles.checkbox, checked[index] ? styles.checkboxDone : null] },
        checked[index] ? React.createElement(Text, { style: styles.checkmark }, '✓') : null
      ),
      React.createElement(Text, { style: styles.stepText }, step)
    )),
    React.createElement(Pressable, { onPress: openQuests, accessibilityRole: 'button', style: styles.button },
      React.createElement(Text, { style: styles.buttonText }, 'Open Discord Quests ↗')
    ),
    React.createElement(Pressable, { onPress: resetChecklist, accessibilityRole: 'button', style: [styles.button, styles.buttonSecondary] },
      React.createElement(Text, { style: [styles.buttonText, styles.secondaryText] }, 'Reset checklist')
    ),
    React.createElement(Text, { style: styles.status }, status),
    React.createElement(Text, { style: styles.note }, 'Safety note: this plugin does not fake a desktop User-Agent, invent game or stream activity, or send progress requests. Quest completion depends on doing the activity that Discord lists.'),
    React.createElement(Text, { style: styles.note }, 'Network behavior: this plugin does not make background requests. The Open button only asks Android to open the official Discord Quest URL.')
  );
}

export default plugin({
  start({ logger } = {}) {
    logger?.log?.('Mauve Quest Helper loaded (manual checklist mode).');
  },
  stop({ logger } = {}) {
    logger?.log?.('Mauve Quest Helper stopped.');
  },
  SettingsComponent
});
