# Mauve Quest Helper — Revenge plugin

A mobile-first, Catppuccin Mocha / Mauve-styled helper UI ported from the uploaded Discord Web Quest Completer extension.

## What's included

- A Revenge settings page with a mauve-themed manual quest checklist.
- A shortcut that asks Android to open Discord's official `https://discord.com/quest-home` page.
- A reset button and simple local checklist state.

## Intentionally not ported

The original extension overrides the browser User-Agent/platform, fabricates running-game and stream state, and sends progress updates that can falsely report quest activity. This port omits that behavior. It does not read private Discord internals, modify request headers, or send quest-progress requests.

## Package

`manifest.json` and `index.js` are at the archive root. The package uses Revenge's external plugin manifest format and JavaScript entrypoint. It was syntax-checked and the archive layout was checked, but it has not been run inside a live Revenge/Discord 348.10 installation, so runtime compatibility is not confirmed.

## Install notes

Use Revenge's plugin/repository flow if your build accepts plugin ZIP packages. If the UI only accepts a repository URL, the ZIP must first be hosted as a Revenge repository artifact; this file is not a raw URL install source. Disable/remove the plugin if the settings page errors, and do not clear Discord app data to troubleshoot it.
